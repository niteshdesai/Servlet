

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/practical2")
public class practical2 extends HttpServlet {

   


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>Servlet Info</title></head>");
        out.println("<body>");
        out.println("<h1>Servlet Information</h1>");

        // Print all init parameters
        out.println("<h2>Init Parameters:</h2>");
        ServletConfig config = getServletConfig();
        Enumeration<String> initParams = config.getInitParameterNames();
        if (initParams.hasMoreElements()) {
            out.println("<ul>");
            while (initParams.hasMoreElements()) {
                String paramName = initParams.nextElement();
                String paramValue = config.getInitParameter(paramName);
                out.printf("<li>%s: %s</li>%n", paramName, paramValue);
            }
            out.println("</ul>");
        } else {
            out.println("<p>No init parameters defined.</p>");
        }

        // Print HTTP request headers
        out.println("<h2>HTTP Request Headers:</h2>");
        Enumeration<String> headerNames = request.getHeaderNames();
        if (headerNames.hasMoreElements()) {
            out.println("<ul>");
            while (headerNames.hasMoreElements()) {
                String headerName = headerNames.nextElement();
                String headerValue = request.getHeader(headerName);
                out.printf("<li>%s: %s</li>%n", headerName, headerValue);
            }
            out.println("</ul>");
        } else {
            out.println("<p>No headers available.</p>");
        }

        // Print client and browser details
        out.println("<h2>Client/Browser Details:</h2>");
        String clientIP = request.getRemoteAddr();
        String clientHost = request.getRemoteHost();
        String userAgent = request.getHeader("User-Agent");
        out.printf("<p>Client IP Address: %s</p>%n", clientIP);
        out.printf("<p>Client Hostname: %s</p>%n", clientHost);
        out.printf("<p>Browser/User-Agent: %s</p>%n", userAgent);

        // Print server details
        out.println("<h2>Server Details:</h2>");
        String serverName = request.getServerName();
        int serverPort = request.getServerPort();
        out.printf("<p>Server Name: %s</p>%n", serverName);
        out.printf("<p>Server Port: %d</p>%n", serverPort);

        out.println("</body>");
        out.println("</html>");
    }

  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response); // Handle POST the same way as GET
    }
}
